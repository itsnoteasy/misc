# DISCIPLINE
 65% keyboard assembled with only through hole components, including usb type-c

[BOM, Build Guide, and Flashing Information](./doc)

Ansi (lol) kits available at [cftkb.com](https://www.cftkb.com)

![discipline](./doc/images/discipline_iso_kicad.png)
![](./doc/images/discipline-iso.png)

