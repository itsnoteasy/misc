# discipline_iso_fork
I'm not the creator of this board, I just changed it a little. see: https://github.com/coseyfannitutti/discipline

apologies for the missing diode beside the left shift switch, it's fixed now.
