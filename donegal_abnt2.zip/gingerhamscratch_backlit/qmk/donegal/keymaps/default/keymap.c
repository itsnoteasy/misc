/* Copyright 2018 Yiancar
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
https://github.com/qmk/qmk_firmware/blob/master/quantum/keymap_extras/keymap_br_abnt2.h
 https://github.com/qmk/qmk_firmware/issues/6325 SEE HERE IF br COMPILE FAILS
*/
//#include QMK_KEYBOARD_H
#include "keymap_uk.h"
#include "donegal.h"
#define _ZERO 0
#define _F12 1
const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
	[_ZERO] = KEYMAP(
		UK_ESC, UK_1, UK_2, UK_3, UK_4, UK_5, UK_6, UK_7, UK_8, UK_9, UK_0, UK_MINS, UK_EQL, UK_P1, UK_BSPC, 
		UK_TAB, UK_Q, UK_W, UK_E, UK_R, UK_T, UK_Y, UK_U, UK_I, UK_O, UK_P, UK_LBRC, UK_RBRC, UK_ENT,
		UK_DEL, UK_A, UK_S, UK_D, UK_F, UK_G, UK_H, UK_J, UK_K, UK_L, UK_SCLN, UK_QUOT, KC_NUHS,  
		UK_LSFT, UK_BSLS, UK_Z, UK_X, UK_C, UK_V, UK_B, UK_N, UK_M, UK_COMM, UK_DOT, UK_SLSH, UK_P5, UK_UP,
		UK_LCTL, MO(1), UK_LALT, UK_SPC, UK_RALT, UK_DOWN, UK_LEFT, UK_RGHT),

	[_F12] = KEYMAP(
		KC_GRV, KC_F1, KC_F2, KC_F3, KC_F4, KC_F5, KC_F6, KC_F7, KC_F8, KC_F9, KC_F10, KC_F11, KC_F12, KC_TRNS, KC_DEL,
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_PGUP, KC_PGDN, KC_TRNS,
        KC_CAPS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS,
        KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_HOME, KC_END, KC_TRNS, KC_TRNS, KC_TRNS, 
		KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS, KC_TRNS)
};

void matrix_init_user(void) {
  //user initialization
}

void matrix_scan_user(void) {
  //user matrix
}

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
  return true;
}
