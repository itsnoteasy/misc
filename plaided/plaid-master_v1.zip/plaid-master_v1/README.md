Plaid
===============

![plaid](./doc/img/plaid.jpg)

The 4x12 ortholinear keyboard kit made by through hole components only. 

Atmega328p with VUSB on [QMK firmware](https://github.com/qmk/qmk_firmware).

[Build guide and bom is here](./doc)
[ビルドガイドとパーツリストはこちら](./doc)
