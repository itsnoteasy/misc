# Ploopyco Trackball

![Ploopyco Trackball](https://i.redd.it/j7z0y83txps31.jpg)

It's a DIY, QMK Powered Trackball!!!!

Keyboard Maintainer: [Drashna Jael're](https://github.com/yourusername)  
Hardware Supported: ATMega32u4 8MHz(3.3v)  
Hardware Availability: Reddit, [GitHub](https://github.com/ploopyco/mouse)

Make example for this keyboard (after setting up your build environment):

    make mouse/ploopyco_trackball:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
