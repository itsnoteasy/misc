#pragma once

#include "config_common.h"

#define VENDOR_ID       0x1234
#define PRODUCT_ID      0x5678
#define DEVICE_VER      0x0001
#define MANUFACTURER    QMK
#define PRODUCT         108Key-Trackpoint
#define DESCRIPTION     A 108 key ANSI keyboard with a trackpoint and three mouse buttons

#define MATRIX_ROWS 6
#define MATRIX_COLS 22


#define MATRIX_ROW_PINS { F1, F4, F6, F3, F5, F2 }
#define MATRIX_COL_PINS { B6, B5, B3, B4, B2, E7, B1, B0, D7, D3, B7, D2, E0, D5, D4, D1, D0, C3, E6, F0, C7, F7 }
#define UNUSED_PINS     //0    1   2   3   4   5   6   7   8   9  10   11  12  13 14   15 16  17  18  19  20  21  

/* COL2ROW or ROW2COL */
#define DIODE_DIRECTION COL2ROW

#define DEBOUNCE 5

#define LOCKING_SUPPORT_ENABLE
#define LOCKING_RESYNC_ENABLE

#define SOLENOID_PIN C2
//#defineSOLENOID_DEFAULT_DWELL 12 //ms
//#defineSOLENOID_MIN_DWELL 4
//#defineSOLENOID_MAX_DWELL 100


