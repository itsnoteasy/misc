# donegal // Through Hole
1N4729A/3.6V
60% iso-uk/ansi/abnt2 backlit keyboard with only through hole components.   

Keyboard Maintainer: [gipetto](https://github.com/itsnoteasy)  
Hardware Supported: ATMEGA328p with vusb [PCB](https://github.com/itsnoteasy/misc)  
Hardware Availability: no

Make example for this keyboard (after setting up your build environment):
    make donegal:default

Flash firmware:
    // In bootloader mode (or)
 make donegal:default:program
 make donegal:default:flash
bootloader doesn't work for the time being. i deleted the last line in donegal.hex and copied the usbasp bootloader onto the end in a test editor, then flashed over avrisp using a teensy2.0(following the qmk isp flashing guide) 
avrdude -c avrisp -p m328p -P /dev/ttyACM0 -b19200 -U flash:w:donegal_default.hex
avrdude -c usbasp -b19200 -p m328p

    r4

miso     vcc

sck      mosi   c5

reset    gnd

## Bootloader
use usbasploader in my repository.
https://github.com/hsgw/USBaspLoader/tree/plaid


See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
