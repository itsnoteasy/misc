#include "kb.h"
#include "keymap_uk.h"

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {

	KEYMAP(
		UK_ESC,  UK_F1,   UK_F2,   UK_F3,  UK_F4,   UK_F5,   UK_F6,   UK_F7,   UK_F8,   UK_F9,            UK_F10,  UK_F11,  UK_F12,  KC_PSCR, KC_SLCK, KC_PAUS, KC_CALC, KC_VOLD, KC_VOLU, 
		UK_GRV,  UK_1,    UK_2,    UK_3,   UK_4,    UK_5,    UK_6,    UK_7,    UK_8,    UK_9,    UK_0,    UK_MINS, UK_EQL,  UK_BSPC, UK_INS,  UK_HOME, UK_PGUP, KC_NLCK, KC_SLSH, UK_ASTR, UK_MINS, 
		UK_TAB,  UK_Q,    UK_W,    UK_E,   UK_R,    UK_T,    UK_Y,    UK_U,    UK_I,    UK_O,    UK_P,    UK_LBRC, UK_RBRC, UK_ENT,  UK_DEL,  UK_END,  UK_PGDN, UK_7,    KC_8,    UK_9, 
		KC_CAPS, UK_A,    UK_S,    UK_D,   UK_F,    UK_G,    UK_H,    UK_J,    UK_K,    UK_L,    UK_SCLN, UK_QUOT, KC_NUHS,                                     UK_4,    UK_5,    UK_6,    KC_PLUS, 
		UK_LSFT, KC_NUBS, UK_Z,    UK_X,   UK_C,    UK_V,    UK_B,    UK_N,    UK_M,    UK_COMM, UK_DOT,  UK_SLSH, UK_RSFT,                   UK_UP,            UK_1,    UK_2,    UK_3, 
		KC_LCTL, UK_LGUI, UK_LALT,                           UK_SPC,                             UK_RALT, KC_F14,  KC_F13,  UK_RCTL, UK_LEFT, UK_DOWN, UK_RGHT, UK_0,  UK_DOT,    UK_ENT)
};

void matrix_init_user(void) {
}

void matrix_scan_user(void) {
}
/*
bool process_record_user(uint16_t keycode, keyrecord_t *record) {
	return true;
}
*/
void led_set_user(uint8_t usb_led) {

	if (usb_led & (1 << USB_LED_NUM_LOCK)) {
		
	} else {
		
	}

	if (usb_led & (1 << USB_LED_CAPS_LOCK)) {
		
	} else {
		
	}

	if (usb_led & (1 << USB_LED_SCROLL_LOCK)) {
		
	} else {
		
	}

	if (usb_led & (1 << USB_LED_COMPOSE)) {
		
	} else {
		
	}

	if (usb_led & (1 << USB_LED_KANA)) {
		
	} else {
		
	}

}

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (keycode == KC_F13 && record->event.pressed) {
        tap_code16(LALT(KC_D));
        wait_ms(10);
        tap_code16(LCTL(KC_C));
        wait_ms(10);
        tap_code16(LCTL(KC_V));
        wait_ms(10);
        tap_code(KC_ENT);
        return false;
    }
    if (keycode == KC_F14 && record->event.pressed) {
        register_code(KC_LSFT);
        return false;
    }
    return true;
}
/*
bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (keycode == KC_F13 && record->event.pressed) {
        tap_code16(KC_0);
        wait_ms(10);
        tap_code16(KC_X);
        wait_ms(10);
        tap_code16(KC_END);
        wait_ms(10);
        tap_code(KC_COMM);
        wait_ms(10);
        tap_code16(KC_HOME);
        wait_ms(10);
        tap_code16(KC_DOWN);
        wait_ms(10);
        return false;
    }
    return true;
}
*/
